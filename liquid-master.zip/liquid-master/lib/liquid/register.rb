# frozen_string_literal: true

module Liquid
  class Register
  end
end
